package Exercícios;

import java.util.Scanner;

public class horas {
    public static void main(String[] args){
        Scanner sc = new Scanner((System.in));
        System.out.print("Digite as horas (sem os minutos): ");
        float horas = sc.nextFloat();

        System.out.print("Digite os minutos: ");
        float minutos = sc.nextFloat();

        float minutos_totais = (horas * 60 ) + minutos;
        System.out.println("Os minutos totais são: " + minutos_totais);
    }
}
