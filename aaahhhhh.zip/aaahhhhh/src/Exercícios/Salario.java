package Exercícios;

import java.util.Scanner;

public class Salario {
    public static void main(String [] args){
        Scanner sc = new Scanner((System.in));
        System.out.print("Digite o salário: R$");
        float salario = sc.nextFloat();

        System.out.print("Digite o percentual para o reajuste (em decimal): ");
        float reajuste = sc.nextFloat();

        float percentual = salario * reajuste;
        System.out.println("O reajuste é no valor de é: R$" + percentual);

        float salario_novo = salario + percentual;
        System.out.println("O reajuste é no valor de é: R$" + salario_novo);

    }
}
