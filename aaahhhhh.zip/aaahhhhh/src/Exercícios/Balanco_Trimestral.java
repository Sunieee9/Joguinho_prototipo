package Exercícios;

public class Balanco_Trimestral {

    // Exercício 1
    public static void main(String[] args){
        float gastosJaneiro = 15000;
        float gastosFevereiro = 23000;
        float gastosMarco = 17000;
        float gastosTrimestral = gastosJaneiro + gastosFevereiro + gastosMarco;
        System.out.println("Os gastos trimestrais são de: R$" + gastosTrimestral);

        //Exercício 2
        float mediaMensal = gastosTrimestral / 3;
        System.out.println("Valor da média mensal: R$" + mediaMensal);
    }
}
