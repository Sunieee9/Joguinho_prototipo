package Exercícios;

import java.util.Scanner;

public class telefone {
    public static void main(String[] args){
        double assinatura = 17.90;
        double local= 0.04;
        double interurbano = 0.2;
        double chamada_interurbano = 0.2;

        Scanner sc = new Scanner((System.in));
        System.out.print("Digite quantos minutos teve as chamadas locais: ");
        int minutos_local = sc.nextFloat();

        System.out.print("Digite quantos minutos teve as chamadas de celular: ");
        int minutos_cel = sc.nextFloat();
    }
}
