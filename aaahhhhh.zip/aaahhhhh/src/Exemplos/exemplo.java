package Exemplos;

public class exemplo {
    public static void main(String[] args){
        int m
                =  5;
        int x = m++;
        System.out.println("m = " + m + " x = " +x );

        int n =  5;
        int y = ++n;
        System.out.println("n = " + n + " y = " +y );
    }
}
