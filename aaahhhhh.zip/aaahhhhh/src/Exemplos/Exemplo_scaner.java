package Exemplos;

import java.util.Scanner;

public class Exemplo_scaner {
    public static void main(String [] agrs){
        Scanner sc = new Scanner((System.in));
        System.out.print("Digite seu nome: ");
        String nome = sc.next();
        System.out.println("Olá, " + nome + "!");
    }
}
